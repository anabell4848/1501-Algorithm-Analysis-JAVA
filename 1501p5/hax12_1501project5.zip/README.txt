hax12@pitt.edu
CS1501


compile with javac GraphTester.java
run with java GraphTester



GraphTester is the main file to run.