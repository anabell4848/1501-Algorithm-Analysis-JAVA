
public interface searchTest {
	
	public void insert(String s);
	
	public boolean find(String s);

}